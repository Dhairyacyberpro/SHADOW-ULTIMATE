package com.shadow.ultimate;

import android.app.Service;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.TextView;

public class FloatingOrbService extends Service {
    private WindowManager wm; private View orb;
    @Override public void onCreate(){ super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); TextView v=new TextView(this); v.setText("S"); v.setTextColor(0xffffffff); v.setTextSize(27); v.setGravity(Gravity.CENTER); v.setBackground(makeBackground()); orb=v;
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(76,76,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT); p.gravity=Gravity.TOP|Gravity.RIGHT; p.x=24;p.y=220; wm.addView(orb,p);
        orb.setOnClickListener(view->{ ShadowVoiceService.wake(this); });
        orb.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;return false;}if(e.getAction()==2){p.x=ox+(int)(sx-e.getRawX());p.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(orb,p);return true;}return false;}});
    }
    private android.graphics.drawable.Drawable makeBackground(){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setShape(1);d.setColor(0xff007dff);d.setStroke(4,0xff68dcff);return d;}
    @Override public void onDestroy(){if(orb!=null)wm.removeView(orb);super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}

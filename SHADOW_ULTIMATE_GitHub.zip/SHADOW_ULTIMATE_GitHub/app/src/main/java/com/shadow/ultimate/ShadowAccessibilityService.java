package com.shadow.ultimate;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class ShadowAccessibilityService extends AccessibilityService {
    private static ShadowAccessibilityService instance;
    @Override protected void onServiceConnected(){instance=this;}
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(instance==this)instance=null;super.onDestroy();}
    public static boolean performScroll(boolean down){if(instance==null)return false; AccessibilityNodeInfo root=instance.getRootInActiveWindow(); if(root==null)return false; boolean ok=root.performAction(down?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD); root.recycle(); return ok;}
}

package com.shadow.ultimate;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private static final int REQ_AUDIO = 10;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xff030b19);
        getWindow().setNavigationBarColor(0xff030b19);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setGravity(Gravity.CENTER); root.setPadding(28,28,28,28); root.setBackgroundColor(0xff030b19);
        TextView title = new TextView(this); title.setText("SHADOW ULTIMATE"); title.setTextColor(0xff18baff); title.setTextSize(30); title.setGravity(Gravity.CENTER);
        TextView sub = new TextView(this); sub.setText("VOICE • AI • FLOATING ORB"); sub.setTextColor(0xffb7d7ee); sub.setGravity(Gravity.CENTER); sub.setPadding(0,12,0,28);
        status = new TextView(this); status.setText("Ready. Enable permissions, then start SHADOW."); status.setTextColor(-1); status.setGravity(Gravity.CENTER); status.setPadding(0,20,0,20);
        Button mic = button("START VOICE ASSISTANT"); mic.setOnClickListener(v -> startVoice());
        Button orb = button("ENABLE FLOATING ORB"); orb.setOnClickListener(v -> enableOrb());
        Button access = button("ACCESSIBILITY SETTINGS"); access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Button stop = button("STOP SHADOW"); stop.setOnClickListener(v -> { stopService(new Intent(this, ShadowVoiceService.class)); stopService(new Intent(this, FloatingOrbService.class)); status.setText("SHADOW stopped."); });
        root.addView(title); root.addView(sub); root.addView(status); root.addView(mic); root.addView(orb); root.addView(access); root.addView(stop); setContentView(root);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
    }
    private Button button(String label) { Button b=new Button(this); b.setText(label); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,8); b.setLayoutParams(p); return b; }
    private void startVoice() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); status.setText("Grant microphone permission, then press Start again."); return; }
        Intent i = new Intent(this, ShadowVoiceService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("Voice service started. Keep its notification visible.");
    }
    private void enableOrb() {
        if (!Settings.canDrawOverlays(this)) { Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i); status.setText("Allow display over other apps, then tap Enable Floating Orb again."); return; }
        startService(new Intent(this, FloatingOrbService.class)); status.setText("Floating orb enabled. Tap it to issue a command.");
    }
}

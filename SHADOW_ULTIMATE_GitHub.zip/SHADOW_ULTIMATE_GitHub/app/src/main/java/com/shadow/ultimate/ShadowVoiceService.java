package com.shadow.ultimate;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import java.util.*;

public class ShadowVoiceService extends Service {
    private SpeechRecognizer recognizer; private TextToSpeech tts; private boolean sleeping=false, listening=false, stopping=false;
    private static final String CHANNEL="shadow_voice";
    @Override public void onCreate() { super.onCreate(); createNotification(); tts=new TextToSpeech(this, s -> { if(s==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("en","IN")); }); }
    private void createNotification() {
        NotificationManager nm=getSystemService(NotificationManager.class); nm.createNotificationChannel(new NotificationChannel(CHANNEL,"SHADOW microphone",NotificationManager.IMPORTANCE_LOW));
        Intent stop=new Intent(this, ShadowVoiceService.class).setAction("STOP"); PendingIntent pi=PendingIntent.getService(this,1,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,CHANNEL).setContentTitle("SHADOW is active").setContentText("Microphone listening is active. Tap Stop to end.").setSmallIcon(android.R.drawable.ic_btn_speak_now).addAction(new Notification.Action.Builder(null,"Stop",pi).build()).setOngoing(true).build();
        startForeground(41,n);
    }
    @Override public int onStartCommand(Intent i,int flags,int id) {
        if(i!=null && "STOP".equals(i.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if(i!=null && "WAKE".equals(i.getAction())) sleeping=false;
        stopping=false; startRecognition(); return START_NOT_STICKY;
    }
    private void startRecognition() {
        if(stopping || sleeping || listening) return;
        if(!SpeechRecognizer.isRecognitionAvailable(this)) { speak("Speech recognition is unavailable on this device"); return; }
        if(recognizer!=null) recognizer.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) { listening=true; }
            public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){listening=false;}
            public void onError(int e){ listening=false; if(!stopping && !sleeping) new Handler(Looper.getMainLooper()).postDelayed(()->startRecognition(),1200); }
            public void onResults(Bundle b){ listening=false; ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()) handle(a.get(0)); if(!stopping&&!sleeping) new Handler(Looper.getMainLooper()).postDelayed(()->startRecognition(),500); }
            public void onPartialResults(Bundle b){} public void onEvent(int e,Bundle b){}
        });
        Intent in=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); in.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); in.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN"); in.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"hi-IN"); in.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false); in.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
        try { recognizer.startListening(in); listening=true; } catch(Exception ex) { listening=false; }
    }
    private void handle(String raw) {
        String c=raw.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}\\s]"," ").replaceAll("\\s+"," ").trim();
        if(c.equals("good night shadow")||c.equals("goodnight shadow")) { sleeping=true; speak("Good night. SHADOW is sleeping. Tap the floating orb to wake me."); return; }
        if(c.contains("antar mantra shatni khopda")) { sleeping=false; speak("SHADOW is ready. Start your command with SHADOW."); return; }
        if(sleeping) return;
        if(!c.startsWith("shadow ")) return;
        String cmd=c.substring(7).trim();
        if(cmd.contains("stop listening")||cmd.equals("stop")) { speak("Stopping SHADOW"); stopSelf(); }
        else if(cmd.contains("scroll down")) { boolean ok=ShadowAccessibilityService.performScroll(true); speak(ok?"Scrolling down":"Enable SHADOW accessibility service first"); }
        else if(cmd.contains("scroll up")) { boolean ok=ShadowAccessibilityService.performScroll(false); speak(ok?"Scrolling up":"Enable SHADOW accessibility service first"); }
        else if(cmd.contains("open youtube")) openPackage("com.google.android.youtube","YouTube");
        else if(cmd.contains("open chrome")) openPackage("com.android.chrome","Chrome");
        else if(cmd.contains("open settings")) { Intent x=new Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(x); speak("Opening settings"); }
        else if(cmd.contains("hello")||cmd.contains("namaste")) speak("Hello. SHADOW is online and ready.");
        else speak("I heard you. This command is not connected yet.");
    }
    private void openPackage(String pkg,String name) { Intent x=getPackageManager().getLaunchIntentForPackage(pkg); if(x!=null){x.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(x);speak("Opening "+name);}else speak(name+" is not installed"); }
    private void speak(String s) { if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"shadow"); }
    public static void wake(Context c) { Intent i=new Intent(c,ShadowVoiceService.class).setAction("WAKE"); if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i); }
    @Override public void onDestroy(){ stopping=true; if(recognizer!=null){recognizer.cancel();recognizer.destroy();} if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}

# SHADOW ULTIMATE — GitHub cloud-build starter

This is an Android project that can be built from GitHub Actions without installing Android Studio locally.

## What is included
- Native Android app screen
- Foreground microphone service with a visible notification and Stop action
- Speech recognition using the device's configured Android speech recognition provider (Hindi locale requested)
- Commands must begin with `SHADOW `, except `Good night SHADOW`
- Sleep and manual orb-tap wake behavior
- Floating blue orb overlay (requires Draw over other apps permission)
- User-enabled AccessibilityService for best-effort scroll actions
- GitHub Actions workflow that builds a debug APK

## Important limitations
This is a **starter implementation, not a finished commercial-grade assistant**. It does not contain a hosted online AI brain, secure backend, speaker/owner verification, or a dedicated acoustic wake-word model. The custom phrase `ANTAR MANTRA SHATNI KHOPDA` is checked while the voice service is actively listening; it is not a dedicated always-on hotword engine. In sleep mode, tap the floating orb to wake SHADOW. The speech service restarts recognition after each utterance, but Android, the speech provider, battery controls, microphone privacy settings, and background-start restrictions may interrupt it. The orb starts/restarts the voice service when tapped. The service uses a visible notification and must be stopped by the user.

Accessibility scrolling is best-effort and works only where the active app exposes scrollable accessibility nodes. It cannot control every app, game, protected screen, or secure action. Do not enable Accessibility for apps you do not trust.

## Build APK without Android Studio
1. Create a GitHub account and a new **public or private** repository named `SHADOW-ULTIMATE`.
2. Upload the *contents* of this folder to the repository root (not the enclosing folder). Ensure `.github/workflows/android.yml` is included.
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab. Select **Build SHADOW APK**, then **Run workflow** if it did not start automatically.
5. When the run succeeds, open it and download the artifact `SHADOW-ULTIMATE-debug-apk`.
6. Extract the downloaded ZIP on your Android phone and install `app-debug.apk`. Android may ask you to allow installation from your browser/file manager.

## First-run setup on phone
1. Open SHADOW and grant microphone permission.
2. Tap **START VOICE ASSISTANT**. Keep its foreground notification visible.
3. Tap **ENABLE FLOATING ORB**, grant the overlay permission, then tap it again.
4. To use scroll commands, open Accessibility Settings and manually enable SHADOW. You can disable it again there.
5. Tap the floating orb to wake/restart listening after sleep. `Good night SHADOW` enters sleep mode.

## Example commands
- `SHADOW hello`
- `SHADOW open YouTube`
- `SHADOW open Chrome`
- `SHADOW open settings`
- `SHADOW scroll down`
- `SHADOW scroll up`
- `Good night SHADOW`
- `ANTAR MANTRA SHATNI KHOPDA` (only recognized if the speech recognizer returns this phrase)

## Security
No API keys are included. If you later connect an online AI service, put credentials on a trusted HTTPS backend, never in the Android app or GitHub repository. Do not commit passwords, tokens, or private keys.
